import sys

from App.MainWindow import MainWindow
from App.MainWidget import MainWidget
from PySide2.QtWidgets import QApplication, QDesktopWidget, QStyleFactory

if __name__ == "__main__":	
	# Qt Application
	app = QApplication(sys.argv)
	app.setApplicationName("Pyvarium")
	app.setStyle(QStyleFactory.create('Fusion'))
	
	# Central Widget
	mainWidget = MainWidget()
	
	# QMainWindow using central widget
	window = MainWindow(app, mainWidget)
	window.setWindowTitle('Pyvarium v1.0')
	window.resize(1000, 600)
	
	qtRectangle = window.frameGeometry()
	centerPoint = QDesktopWidget().availableGeometry().center()
	qtRectangle.moveCenter(centerPoint)
	window.move(qtRectangle.topLeft())
	
	window.show()

	# Execute application
	sys.exit(app.exec_())

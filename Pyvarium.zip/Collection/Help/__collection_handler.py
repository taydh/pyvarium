def hello():
	print("hello")

collectionHandler = {
	'autorun': True,
	'globalParameter': False,
}

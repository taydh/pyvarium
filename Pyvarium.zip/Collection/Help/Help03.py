def getConfiguration():
	return {
		'title': 'Specification'
	}
	
def run(collectionHandler, params):
	return {
		'status': 'ok',
		'message': 'click to view',
		'data': 1
	}

def generateTextual(result):
	return """Specification
	
There are 2 main things in Spaceman, Collection directory and Module scripts.
This Help Collection, for example, can be viewed in the ./Collection/Help directory that should coming with Spaceman program.
"""
	
def generateGraphical(result):
	return None

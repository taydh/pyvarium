from PySide2.QtWidgets import QScrollArea, QVBoxLayout, QLabel

def getConfiguration():
	return {
		'title': 'Application Functionality'
	}
	
def run(collectionHandler, params):
	return {
		'status': 'ok',
		'message': 'click to view',
		'data': 1
	}

def generateTextual(result):
	return """Application Functionality

1. Load Collection
2. Run Single Module
3. Run All Modules
4. View Module Result
"""
	
def generateGraphical(result):
	widget = QScrollArea()
	layout = QVBoxLayout()
	layout.addWidget(QLabel('Application Functionality'))
	layout.addStretch(1)
	widget.setLayout(layout)
	return widget

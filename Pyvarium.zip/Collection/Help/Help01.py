def getConfiguration():
	return {
		'title': 'Getting Started'
	}
	
def run(collectionHandler, params):
	return {
		'status': 'ok',
		'message': 'click to view',
		'data': 1
	}

def generateTextual(result):
	return """Getting Started
	
Welcome to Spaceman v1.
Spaceman is a simple tool to run one and more our own custom Python scripts (based on Spaceman specification).
The result output of these scripts can be further customized to be viewed either in it's raw form (JSON), textual and graphical representation.
Spaceman only handle the GUI for the script execution and result viewing.

Sample cases that might be performed with Spaceman are:
- Monitoring scripts,
- Execution scripts,
- Analysis scripts,
- Report generation scripts,
- etc.

I hope you will have good time with this tool.
taydh
"""
	
def generateGraphical(result):
	return None

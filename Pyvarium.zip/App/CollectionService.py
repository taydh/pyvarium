import os
import sys
import collections
from importlib import reload
	
class CollectionService():
	def __init__(self, path):
		self.path = path
		sys.path.append(path)
		self.handler = {}
		self.lastResults = {}
		
		# Setup Collection Handler
		collectionHandlerModuleName = '__collection_handler'
		collectionHandlerModule = self.reloadModule('__collection_handler')
		
		if collectionHandlerModule:
			if hasattr(collectionHandlerModule, 'collectionHandler'):
				self.handler = getattr(collectionHandlerModule, 'collectionHandler')
		
		print(self.handler)
	
	def runModule(self, moduleName, params):
		module = self.reloadModule(moduleName)
		
		if hasattr(module, 'run'):
			definition = getattr(module, 'run')
			result = definition(self.handler, params)
			if isinstance(result, collections.Mapping):
				self.lastResults[moduleName] = result
			else:
				self.lastResults[moduleName] = {
					'status': 'n/a',
					'message': '(invalid result type)',
					'data': result
				}
		else:
			self.lastResults[moduleName] = {
				'status': 'n/a',
				'message': '(nothing to run)',
				'data': None
			}
			
		return self.lastResults[moduleName]

	def getLastResult(self, moduleName):
		result = None
		
		if moduleName in self.lastResults:
			result = self.lastResults[moduleName]
		
		return result
		
	def getModule(self, moduleName):
		if moduleName not in sys.modules:
			module = __import__(moduleName)
		else:
			module = sys.modules[moduleName]
		
		return module
	
	def reloadModule(self, moduleName):
		return reload(self.getModule(moduleName))
	
	def getModuleConfiguration(self, moduleName):
		module = self.getModule(moduleName)
		if hasattr(module, 'getConfiguration'):
			return getattr(module, 'getConfiguration')()
	
	def generateModuleTextual(self, moduleName):
		module = self.getModule(moduleName)
		if hasattr(module, 'generateTextual'):
			return getattr(module, 'generateTextual')(self.getLastResult(moduleName))

	def generateModuleGraphical(self, moduleName):
		module = self.getModule(moduleName)
		if hasattr(module, 'generateGraphical'):
			return getattr(module, 'generateGraphical')(self.getLastResult(moduleName))
		
	def getModuleListFromFileSystem(self):
		files = os.listdir(self.path)
		result = []
		
		for fname in files:
			if os.path.isfile(self.path + '/' + fname) and (fname != '__collection_handler.py') and fname[-3:] == '.py':
				result.append(fname[:-3])
				
		result.sort()
		return result

	def useGlobalParameter(self):
		return 'globalParameter' in self.handler and self.handler['globalParameter'] == True
		
	def isAutorun(self):
		return 'autorun' in self.handler and self.handler['autorun'] == True

	def destroy(self):
		sys.path.remove(self.path)
		del sys.modules['__collection_handler']

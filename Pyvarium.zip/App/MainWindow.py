from PySide2.QtCore import Qt, Slot, Signal
from PySide2.QtWidgets import QMainWindow, QLabel, QAction

class MainWindow(QMainWindow):
	def __init__(self, app, mainWidget):
		QMainWindow.__init__(self)
		
		self.app = app
		self.originalPalette = app.palette()

		# Menu
		self.menu = self.menuBar()
		self.file_menu = self.menu.addMenu("File")
		
		# Exit QAction
		exit_action = QAction("Exit", self)
		exit_action.setShortcut("Ctrl+Q")
		exit_action.triggered.connect(self.quitApp)
		self.file_menu.addAction(exit_action)
		
		# Status
		self.statusLabel = QLabel()
		self.statusBar = self.statusBar()
		self.statusBar.addWidget(self.statusLabel)

		self.setCentralWidget(mainWidget)
		
		mainWidget.statusChanged.connect(self.setStatusLabel)
	
	@Slot()
	def quitApp(self, checked):
		self.app.quit()
		
	@Slot(str)
	def setStatusLabel(self, text):
		self.statusLabel.setText(text)

import os
import json
from App.CollectionService import CollectionService
from PySide2.QtCore import Qt, Slot, Signal
from PySide2.QtGui import QFont
from PySide2.QtWidgets import (QWidget, QHeaderView, QHBoxLayout, QVBoxLayout, QLabel, QLineEdit,
								QPushButton, QTableWidget, QTableWidgetItem,
								QPlainTextEdit, QScrollArea, QTabWidget, QGroupBox)

class MainWidget(QWidget):
	statusChanged = Signal(str)

	def __init__(self):
		QWidget.__init__(self)

		self.window = None
		self.collectionService = None
		self.tableItems = 0
		self.currentResultModuleName = ''
		self.resultViewPool = {}
		
		self.txtSourcePath = QLineEdit()
		self.txtSourcePath.setText('./Collection/Help')
		self.btnReload = QPushButton("Connect")
		
		self.lblGlobalParams = QLabel('Parameter')
		self.lblGlobalParams.hide()
		self.txtGlobalParams = QLineEdit()
		self.txtGlobalParams.hide()
		
		self.btnRunSourceModule = QPushButton("Run")
		self.btnRunSourceModules = QPushButton("Run All")
		
		self.resultInfoLabel = QLabel()
		self.resultLabel = QPlainTextEdit()
		self.resultLabel.setReadOnly(True)
		self.resultGraphical = QWidget()
		self.resultGraphicalLayout = QVBoxLayout()
		self.resultGraphical.setLayout(self.resultGraphicalLayout)
		self.resultRaw = QPlainTextEdit()
		self.resultRaw.setReadOnly(True)
		self.resultRaw.setStyleSheet("background-color:black;color:white;");
		self.resultRaw.setFont(QFont("Courier", 10))
		
		# result tab
		self.resultTab = QTabWidget()
		self.resultTab.addTab(self.resultLabel, 'Textual')
		self.resultTab.addTab(self.resultGraphical, 'Graphical')
		self.resultTab.addTab(self.resultRaw, 'Raw Result')
		self.btnQuit = QPushButton("Quit")

		# Modules Table
		self.table = QTableWidget()
		self.table.setColumnCount(3)
		self.table.setHorizontalHeaderLabels(["Module", "Status", "Message"])
		self.table.setColumnWidth(0, 200)
		self.table.setColumnWidth(1, 75)
		self.table.horizontalHeader().setStretchLastSection(True)
		self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
		self.table.cellClicked.connect(self.cellClicked)
		self.table.itemSelectionChanged.connect(self.itemSelectionChanged)

		# Left
		leftLayout = QVBoxLayout()
		leftLayout.addWidget(self.lblGlobalParams)
		leftLayout.addWidget(self.txtGlobalParams)
		leftLayout.addWidget(self.table)
		leftLayout.addWidget(self.btnRunSourceModule)
		leftLayout.addWidget(self.btnRunSourceModules)
		leftGroupBox = QGroupBox('Modules')
		leftGroupBox.setLayout(leftLayout)
		
		# Right
		resultInfoLayout = QHBoxLayout()
		resultInfoLayout.addWidget(QLabel('Module:'))
		resultInfoLayout.addWidget(self.resultInfoLabel)
		resultInfoLayout.addStretch(1)
		rightLayout = QVBoxLayout()
		rightLayout.addLayout(resultInfoLayout)
		rightLayout.addWidget(self.resultTab)
		rightLayout.addWidget(self.btnQuit)
		rightGroupBox = QGroupBox('Result Viewer')
		rightGroupBox.setLayout(rightLayout)
		#rightGroupBox.hide()

		# Top Layout
		topLayout = QHBoxLayout()
		topLayout.addWidget(QLabel('Collection Path'))
		topLayout.addWidget(self.txtSourcePath)
		topLayout.addWidget(self.btnReload)

		#self.table_view.setSizePolicy(size)
		
		# Middle Layout
		middleLayout = QHBoxLayout()
		middleLayout.addWidget(leftGroupBox)
		middleLayout.addWidget(rightGroupBox)
		middleLayout.setSpacing(15)
		
		# Master Layout
		masterLayout = QVBoxLayout()
		masterLayout.addLayout(topLayout)
		masterLayout.addLayout(middleLayout)

		# Set the layout to the QWidget
		self.setLayout(masterLayout)

		# Signals and Slots
		self.btnReload.clicked.connect(self.reloadCollection)
		self.btnRunSourceModule.clicked.connect(self.runModuleItem)
		self.btnRunSourceModules.clicked.connect(self.runAllModuleItems)
		self.btnQuit.clicked.connect(self.quitApp)

		self.btnRunSourceModule.setEnabled(False)
	
	@Slot()
	def quitApp(self):
		self.parent().quitApp(None)
		
	@Slot()
	def cellClicked(self, row, col):
		moduleName = self.getModuleNameFromTable(row)
		self.btnRunSourceModule.setEnabled(True)
		
		if self.currentResultModuleName != moduleName:
			self.currentResultModuleName = moduleName
			result = self.collectionService.getLastResult(moduleName)

			if result:
				self.showResult(moduleName)
			#end if
		#end if
	
	@Slot()
	def itemSelectionChanged(self):
		if len(self.table.selectedItems()) == 0:
			self.btnRunSourceModule.setEnabled(False)
		#end if
	
	def reloadCollection(self):
		self.clearTable()
		path = self.txtSourcePath.text()
		
		if not os.path.isdir(path): 
			self.statusChanged.emit('please provide a directory')
			return
		#end if
		
		self.lblGlobalParams.hide()
		self.txtGlobalParams.hide()
		self.resultInfoLabel.setText('')
		self.resultLabel.clear()
		self.clearResultGraphical()
		self.resultTab.setCurrentIndex(0)
		self.currentResultModuleName = ''
		
		source = self.setCollectionService(path)
		sourceModules = self.collectionService.getModuleListFromFileSystem()
		
		for moduleName in sourceModules:
			self.table.insertRow(self.tableItems)
			
			moduleLabel = self.getModuleLabel(moduleName)
			colName = QTableWidgetItem(moduleLabel)
			colStatus = QTableWidgetItem('')
			colStatus.setTextAlignment(Qt.AlignCenter | Qt.AlignVCenter)
			colMessage = QTableWidgetItem('')
			colMessage.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

			self.table.setItem(self.tableItems, 0, colName)
			self.table.setItem(self.tableItems, 1, colStatus)
			self.table.setItem(self.tableItems, 2, colMessage)
			
			self.tableItems += 1
		#end for
		
		if self.collectionService.useGlobalParameter() == True:
			self.lblGlobalParams.show()
			self.txtGlobalParams.show()
		#end if
		
		if self.collectionService.isAutorun():
			self.runAllModuleItems()
		#end if
			
		self.statusChanged.emit('Collection reloaded')
	
	def clearResultGraphical(self):
		#remove resultGraphical widget
		layout = self.resultGraphicalLayout
		widgetItem = layout.itemAt(0)
		
		if widgetItem:
			widget = widgetItem.widget()
			widget.setParent(None)
		#end if
	
	def getModuleNameFromTable(self, row):
		return self.table.item(row, 0).text().split(' ',1)[0]
	
	def getModuleLabel(self, moduleName):
		moduleConfig = self.collectionService.getModuleConfiguration(moduleName)
		title = moduleConfig['title'] if moduleConfig and 'title' in moduleConfig else ''
		return moduleName if len(title) == 0 else moduleName + ' - ' + title
	
	def runModule(self, moduleName, row):
		self.statusChanged.emit('running ' + moduleName)
		result = self.collectionService.runModule(moduleName, self.txtGlobalParams.text())
		self.table.item(row, 1).setText(result['status'])
		self.table.item(row, 2).setText(result['message'])
		self.resultViewPool[moduleName] = None
		
		return result
	
	def getResultView(self, moduleName):
		if moduleName not in self.resultViewPool:
			resultViewPool[moduleName] = None
		#end if
		
		if self.resultViewPool[moduleName] == None:
			textual = self.collectionService.generateModuleTextual(moduleName)
			graphical = self.collectionService.generateModuleGraphical(moduleName)
			result = self.collectionService.getLastResult(moduleName)
			
			if not textual: textual = ''
			if not graphical: graphical = QWidget()
			
			self.resultViewPool[moduleName] = {
				'textual': textual,
				'graphical': graphical,
				'raw': json.dumps(result)
			}
		#end if
		
		return self.resultViewPool[moduleName]
	
	def showResult(self, moduleName):
		resultView = self.getResultView(moduleName)
		self.currentResultModuleName = moduleName
			
		self.resultInfoLabel.setText(self.getModuleLabel(moduleName))
		self.resultLabel.clear()
		self.resultLabel.insertPlainText(resultView['textual'])
		self.clearResultGraphical()
		self.resultGraphical.layout().addWidget(resultView['graphical'])
		self.resultRaw.clear()
		self.resultRaw.insertPlainText(resultView['raw'])
	
	def runModuleItem(self):
		self.btnRunSourceModule.setEnabled(False)
		row = self.table.currentItem().row()
		moduleName = self.getModuleNameFromTable(row)
		self.runModule(moduleName, row)
		self.showResult(moduleName)
		self.btnRunSourceModule.setEnabled(True)
		self.statusChanged.emit('finish running module')
			
	def runAllModuleItems(self):
		self.btnRunSourceModules.setEnabled(False)
		for row in range(self.table.rowCount()):
			moduleName = self.getModuleNameFromTable(row)
			self.runModule(moduleName, row)
		#end for
		self.btnRunSourceModules.setEnabled(True)
		self.statusChanged.emit('finish running all modules')
	#end def

	def clearTable(self):
		self.table.setRowCount(0)
		self.tableItems = 0
		
	def setCollectionService(self, path):
		if self.collectionService:
			self.collectionService.destroy()
		#end if
			
		self.collectionService = CollectionService(path)
